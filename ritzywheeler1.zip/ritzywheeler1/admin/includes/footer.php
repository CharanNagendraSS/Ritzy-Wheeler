<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
      <b>privacy policy</b>
    </div>
    <strong>Copyright &copy; 2018 Brought To You By <small>msh</small></strong>
</footer>