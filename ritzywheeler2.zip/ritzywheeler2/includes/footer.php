<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
        <br>
        <b>privacy policy</b>
      </div>
      <strong>Copyright &copy; 2020 Brought to You By <small>msh</small></strong>
    </div>
</footer>